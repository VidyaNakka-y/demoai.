// package com.example.demoAi.service;

// import com.fasterxml.jackson.databind.JsonNode;
// import com.fasterxml.jackson.databind.ObjectMapper;
// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.stereotype.Service;

// import java.net.URI;
// import java.net.http.HttpClient;
// import java.net.http.HttpRequest;
// import java.net.http.HttpResponse;
// import java.nio.charset.StandardCharsets;
// import java.time.Duration;

// @Service
// public class AiSqlService {

//     @Value("${HUGGINGFACE_API_KEY}")
//     private String hfKey;

//     private final ObjectMapper mapper = new ObjectMapper();
//     private final HttpClient client = HttpClient.newHttpClient();

//     public String generateSql(String userRequest) throws Exception {

//         if (hfKey == null || hfKey.isBlank()) {
//             throw new IllegalStateException("HUGGINGFACE_API_KEY not configured");
//         }

//         // 🔥 SYSTEM PROMPT
//         String systemPrompt = """
//                 You are an expert SQL query generator for a MySQL database.

//                 STRICT RULES:
//                 1. Only generate ONE SELECT statement.
//                 2. Never generate INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE.
//                 3. No explanations.
//                 4. No markdown.
//                 5. No comments.
//                 6. No multiple statements.
//                 7. Always use exact column names from schema.
//                 8. Always return raw SQL only.
//                 """;

//         // 🔥 USER PROMPT WITH SCHEMA
//         String userPrompt = """
//                 Database Schema:

//                 Table: employees
//                 Columns:
//                 - id BIGINT
//                 - name VARCHAR
//                 - role VARCHAR
//                 - salary DOUBLE

//                 Rules:
//                 - Use WHERE for filtering.
//                 - Use >, <, >=, <= for numeric comparison.
//                 - Use = for exact match.
//                 - Salary mentioned in thousands must be converted (e.g., 55 thousand = 55000).
//                 - String values must use single quotes.
//                 - Numeric values must NOT use quotes.

//                 Generate SQL for:
//                 """ + userRequest;

//         // 🔥 Build JSON body
//         var bodyNode = mapper.createObjectNode();
//         bodyNode.put("model", "meta-llama/Llama-3.1-8B-Instruct");
//         bodyNode.put("temperature", 0);

//         var messages = bodyNode.putArray("messages");

//         messages.add(mapper.createObjectNode()
//                 .put("role", "system")
//                 .put("content", systemPrompt));

//         messages.add(mapper.createObjectNode()
//                 .put("role", "user")
//                 .put("content", userPrompt));

//         String body = mapper.writeValueAsString(bodyNode);

//         HttpRequest request = HttpRequest.newBuilder()
//                 .uri(URI.create("https://router.huggingface.co/v1/chat/completions"))
//                 .timeout(Duration.ofSeconds(60))
//                 .header("Authorization", "Bearer " + hfKey)
//                 .header("Content-Type", "application/json")
//                 .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
//                 .build();

//         HttpResponse<String> response =
//                 client.send(request, HttpResponse.BodyHandlers.ofString());

//         if (response.statusCode() / 100 != 2) {
//             throw new IllegalStateException("Hugging Face API error: " + response.body());
//         }

//         JsonNode root = mapper.readTree(response.body());

//         String sql = root.path("choices")
//                 .get(0)
//                 .path("message")
//                 .path("content")
//                 .asText("")
//                 .trim();

//         // 🔥 REMOVE TRAILING SEMICOLON SAFELY
//         if (sql.endsWith(";")) {
//             sql = sql.substring(0, sql.length() - 1).trim();
//         }

//         // 🛡 VALIDATION LAYER

//         if (sql.isBlank()) {
//             throw new IllegalArgumentException("AI returned empty SQL");
//         }

//         String lowerSql = sql.toLowerCase();

//         // Must start with SELECT
//         if (!lowerSql.startsWith("select")) {
//             throw new IllegalArgumentException("Only SELECT queries allowed: " + sql);
//         }

//         // Block dangerous keywords using word boundaries
//         if (lowerSql.matches(".*\\b(drop|delete|update|insert|alter|truncate|create)\\b.*")) {
//             throw new IllegalArgumentException("Dangerous SQL detected: " + sql);
//         }

//         // Only allow employees table
//         if (!lowerSql.contains("employees")) {
//             throw new IllegalArgumentException("Only employees table is allowed");
//         }

//         return sql;
//     }
// }
package com.example.demoAi.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class AiSqlService 
{

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${HUGGINGFACE_API_KEY}")
    private String apiKey;

    public String generateSql(String userRequest) 
    {

        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("HUGGINGFACE_API_KEY not configured");
        }

        String url = "https://router.huggingface.co/v1/chat/completions";

        // 🔥 STRICT PROMPT
        String prompt = """
You are an expert MySQL query generator.

STRICT RULES:
1. Generate ONLY ONE SELECT statement.
2. Do NOT generate INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE.
3. No explanation.
4. No markdown.
5. No comments.
6. Salary mentioned in thousands must be converted (55 thousand = 55000).
7. Use exact column names.
8. Return raw SQL only.

Database Schema:

Table: employees
Columns:
- id BIGINT
- name VARCHAR
- role VARCHAR
- salary DOUBLE

Generate SQL for:
""" + userRequest;

        // 🔥 Request body
        Map<String, Object> body = new HashMap<>();
        body.put("model", "meta-llama/Llama-3.1-8B-Instruct");
        body.put("temperature",0);

        List<Map<String, String>> messages = new ArrayList<>();

        Map<String, String> userMessage = new HashMap<>();
        userMessage.put("role", "user");
        userMessage.put("content", prompt);

        messages.add(userMessage);
        body.put("messages", messages);

        // 🔥 Headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        HttpEntity<Map<String, Object>> request =
                new HttpEntity<>(body, headers);

        try {
            ResponseEntity<Map> response =
                    restTemplate.postForEntity(url, request, Map.class);

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new RuntimeException("AI API error: " + response.getStatusCode());
            }

            Map responseBody = response.getBody();

            List choices = (List) responseBody.get("choices");
            Map firstChoice = (Map) choices.get(0);
            Map message = (Map) firstChoice.get("message");

            String sql = message.get("content").toString().trim();

            // Remove trailing semicolon
            if (sql.endsWith(";")) {
                sql = sql.substring(0, sql.length() - 1).trim();
            }

            System.out.println("Generated SQL: " + sql);

            // 🔐 VALIDATION LAYER
            validateSql(sql);

            return sql;

        } catch (Exception e) {
            throw new RuntimeException("Error calling AI: " + e.getMessage());
        }
    }

    private void validateSql(String sql) {

        String lower = sql.toLowerCase();

        // if (sql.isBlank()) {
        //     throw new IllegalArgumentException("AI returned empty SQL");
        // }

        // if (!lower.startsWith("select")) {
        //     throw new IllegalArgumentException("Only SELECT statements allowed");
        // }

        // if (lower.matches(".*\\b(drop|delete|update|insert|alter|truncate|create)\\b.*")) {
        //     throw new IllegalArgumentException("Dangerous SQL detected");
        // }

        // if (!lower.contains("employees")) {
        //     throw new IllegalArgumentException("Only employees table is allowed");
        // }
    }
}



// You are sending an HTTP request from your Spring Boot application to an AI API.
// In any HTTP request there are two main parts:

// 1️⃣ Headers → Information about the request
// 2️⃣ Body → The actual data you send

// 1️⃣ Real Life Example (Very Easy to Understand)

// Think of sending a courier package 📦

// Part	Real Life Example	In API
// Address label	Who to send	Headers
// Package content	What you send	Body

// So:

// Headers = instructions / metadata

// Body = actual message/data


// 2️⃣ What Is This Code Doing?

// Your Spring Boot app is preparing a POST request to an AI model.

// Map<String, Object> body = new HashMap<>();

// Here you are creating the body of the request.

// 3️⃣ Request Body Explained
// body.put("model", "meta-llama/Llama-3.1-8B-Instruct");

// This tells the API:

// 👉 Which AI model to use

// Example:

// Use this AI model to generate the answer

//===============================================================================================================

// body.put("temperature",0);

// Temperature controls creativity

// Value	Behavior
// 0	Very accurate
// 0.5	Balanced
// 1	Very creative

// Since you set:

// temperature = 0

// The AI will give very precise answers (good for SQL generation).


//========================================================================================================================

// Messages
// List<Map<String, String>> messages = new ArrayList<>();

// This stores the conversation you send to the AI.

// Example:

// User → "Generate SQL for student table"
// User Message
// Map<String, String> userMessage = new HashMap<>();
// userMessage.put("role", "user");
// userMessage.put("content", prompt);

// This means:

// role = user
// content = your prompt

// Example request:

// {
//  "role": "user",
//  "content": "Generate SQL query for student table"
// }
// Add Message to List
// messages.add(userMessage);
// body.put("messages", messages);

// Final body will look like:

// {
//  "model": "meta-llama/Llama-3.1-8B-Instruct",
//  "temperature": 0,
//  "messages": [
//    {
//      "role": "user",
//      "content": "Generate SQL query"
//    }
//  ]
// }

// This is the data sent to the AI.

//========================================================================================================================


// 4️⃣ Headers Explained

// Headers contain extra information about the request.

// HttpHeaders headers = new HttpHeaders();

// Creating header object.

// Content Type
// headers.setContentType(MediaType.APPLICATION_JSON);

// This tells the server:

// The body is JSON format

// Like saying:

// Hey server, I'm sending JSON data

//=========================================================================================================================



// Authorization
// headers.setBearerAuth(apiKey);

// This sends your API key.

// Actual HTTP header sent:

// Authorization: Bearer sk-xxxxxxxx

// Meaning:

// I am authorized to use this API

// Without this → API will reject the request.


//=========================================================================================================================



// 5️⃣ Final Request Object
// HttpEntity<Map<String, Object>> request =
//         new HttpEntity<>(body, headers);

// This combines everything:

// HTTP Request
//    |
//    |--- Headers
//    |       Authorization
//    |       Content-Type
//    |
//    |--- Body
//            model
//            temperature
//            messages

// So the API receives:

// POST /chat/completions

// Headers:
// Authorization: Bearer API_KEY
// Content-Type: application/json

// Body:
// {
//  "model": "...",
//  "temperature":0,
//  "messages":[...]
// }
// 6️⃣ Visual Flow (Your Spring Boot App)
// Spring Boot App
//       │
//       │ HTTP Request
//       ▼
// AI API Server
//       │
//       │ Process prompt
//       ▼
// AI Model (Llama)
//       │
//       ▼
// Response (Generated SQL)
// 7️⃣ Why This Is Important for Your Project

// You are likely building something like:

// User Question
//      ↓
// Spring Boot
//      ↓
// Send Prompt to AI API
//      ↓
// AI generates SQL
//      ↓
// Execute SQL on Database
//      ↓
// Return results