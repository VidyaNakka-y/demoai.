package com.example.demoAi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAiApplication.class, args);
	}

}
