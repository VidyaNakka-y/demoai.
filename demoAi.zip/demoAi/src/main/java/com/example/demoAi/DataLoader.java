// package com.example.demoAi;

// import com.example.demoAi.model.Employee;
// import com.example.demoAi.repository.EmployeeRepository;
// import org.springframework.boot.CommandLineRunner;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;

// @Configuration
// public class DataLoader {

//     @Bean
//     CommandLineRunner init(EmployeeRepository repo) {
//         return args -> {
//             repo.save(new Employee("Alice Johnson", "Engineer", 75000.0));
//             repo.save(new Employee("Bob Smith", "Manager", 90000.0));
//             repo.save(new Employee("Carol White", "Designer", 55000.0));
//             repo.save(new Employee("David Brown", "Engineer", 50000.0));
//         };
//     }
// }
