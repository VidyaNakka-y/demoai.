package com.example.demoAi.controller;

import com.example.demoAi.service.AiSqlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class QueryController 
{

    //private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(QueryController.class);

    @Autowired
    private AiSqlService aiSqlService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostMapping("/api/query")
    public ResponseEntity<?> query(@RequestBody Map<String, String> body) {
       // log.debug("Received query request body: {}", body);
        try 
        {
            String text = body.get("text");
            if (text == null || text.isBlank()) {
                //log.warn("Request missing 'text' field");
                return ResponseEntity.badRequest().body(Map.of("error", "text is required"));
            }

            String sql = aiSqlService.generateSql(text);
           // log.debug("Generated SQL: {}", sql);

            List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
            return ResponseEntity.ok(Map.of("sql", sql, "rows", rows));
        } catch (IllegalArgumentException e) {
           // log.warn("Client error during query processing", e);
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
           // log.error("Server error while handling query", e);
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }
}
